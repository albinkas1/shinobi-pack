#ifndef SHINOBI_HUD_GLSL
#define SHINOBI_HUD_GLSL
// Exact 26.3 GUI glyph contract. Only the dedicated -8192 ascent font and
// marker red 252 enter this branch. All ordinary GUI/world text stays vanilla.
bool shinobi_hud() {
    ivec3 marker = ivec3(round(Color.rgb * 255.0));
    if (marker.r != 252 || Position.y < 8190.0 || Position.y > 12000.0) return false;
    int data = marker.b;
    bool small = data >= 128;
    if (small) data -= 128;
    int corner = data / 16;
    int palette = data % 16;
    if (corner > 3 || palette > 7) return false;
    mat4 transform = ProjMat * ModelViewMat;
    // Projection uses physical-size / GUI-scale; GuiGraphics uses the ceiling.
    vec2 extent = ceil(abs(vec2(2.0 / transform[0][0], 2.0 / transform[1][1])) - 0.0001);
    // GUI vertices are TL, BL, BR, TR; each glyph remains a complete quad.
    // 26.3 compiles both OpenGL and Vulkan through ShaderC's Vulkan semantics.
    int vertex = gl_VertexIndex % 4;
    bool bottom = vertex == 1 || vertex == 2;
    bool right = vertex >= 2;
    float localX = Position.x - floor(extent.x / 2.0) + (right ? -0.1 : 0.1);
    float x = (corner == 1 || corner == 3 ? extent.x - 152.0 : 8.0) + localX;
    float y = (corner >= 2 ? extent.y - 160.0 : 8.0) + float(marker.g)
        + (bottom ? (small ? 6.0 : 8.0) : 0.0);
    gl_Position = transform * vec4(x, y, Position.z, 1.0);
    vec3 colors[8] = vec3[8](
        vec3(1.0), vec3(244.0,154.0,69.0)/255.0,
        vec3(240.0,234.0,220.0)/255.0, vec3(166.0,174.0,163.0)/255.0,
        vec3(145.0,182.0,95.0)/255.0, vec3(112.0,178.0,193.0)/255.0,
        vec3(236.0,155.0,114.0)/255.0, vec3(185.0,157.0,209.0)/255.0);
    vertexColor = vec4(colors[palette], Color.a);
    texCoord0 = UV0;
    return true;
}
#endif
