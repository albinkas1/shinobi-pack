# Licence and credits

## What this is
An original Minecraft-style fan interpretation of the nine-tailed fox Kurama, made for the private Shinobi Core Paper server.
All geometry, pixel art, rig and animations were made from scratch in this session. Blockbench did the modelling checks,
animation playback, glTF export and renders. The generator scripts are in `source/generator/`.

- No textures, models, animation files or rips were copied or extracted from any game, mod, video or other creator.
- Reference images you added to the concept canvas (official-style artwork plus screenshots of two other creators' 3D models)
  were only looked at for overall pose and proportion cues. None of their geometry, texture, colours or files were used.

## Rights
- Kurama and Naruto are the intellectual property of their rights holders (Masashi Kishimoto / Shueisha and licensees).
  This asset is fan work. Keep it to a private, non-commercial server. Don't sell it, or sell access to it, without permission.
  This is general information, not legal advice.
- For the original work in this folder (geometry, texture, rig, animations, scripts, documents): Bartosz / the Shinobi Core
  project may use, modify and redistribute it for the server, within the character-rights limit above.

## Tools and third-party material
- Blockbench 5.2.1 (GPL-3.0) with its MCP plugin: model checks, animation preview, .bbmodel save, glTF export, renders.
- Claude Design canvas: concept, reference and palette sheets.
- Python 3, NumPy, Pillow, Shapely, Playwright/Chromium: generator, texture painter, checks, sheet PNG export.
- Fonts on the concept sheets: Chakra Petch and IBM Plex Mono (both SIL Open Font License 1.1).
- BetterModel (MIT) is mentioned only as an optional adapter target. It is not included or installed.
